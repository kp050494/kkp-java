package com.springrest.springrest.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.springrest.springrest.model.Courses;

@Service
public class CourseServiceImpl implements CourseService {
	
	List<Courses> list;
	
	

	public CourseServiceImpl() {
		list = new ArrayList<>();
		list.add(new Courses(125, "Java", "Object Oriented Language by Oracle."));
		list.add(new Courses(126, "Python", "Mostly used in Data Science and Machine Learning."));
		list.add(new Courses(127, "C++", "Old Object oriented programming language mostly used in developing system application."));
		
	}



	@Override
	public List<Courses> getCourses() {
		
		return list;
	}



	@Override
	public Courses getCourse(long courseId) {
		Courses c = null;
		for(Courses course:list) {
			if(course.getId() == courseId) {
				c = course;
				break;
			}
		}
		return c;
	}



	@Override
	public Courses addCourse(Courses c) {
			list.add(c);
		return c;
	}

}
